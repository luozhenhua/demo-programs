// You can edit this code!
// Click here and start typing.
// taken from https://golang.org/
package main

import "fmt"

func main() {
	fmt.Println("Hello, 世界")
}
